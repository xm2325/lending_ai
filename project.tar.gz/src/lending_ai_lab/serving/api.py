from __future__ import annotations

from fastapi import FastAPI, HTTPException

from .schemas import CreditRiskResponse, CreditSequenceRequest

app = FastAPI(
    title="Lending AI Lab",
    version="0.1.0",
    description="Research API contract. Model loading is intentionally explicit.",
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/score", response_model=CreditRiskResponse)
def score(_: CreditSequenceRequest) -> CreditRiskResponse:
    raise HTTPException(
        status_code=503,
        detail="No model artifact loaded. Run the demo and wire an approved model artifact before scoring.",
    )
